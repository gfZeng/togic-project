#include "apue.h"
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>

#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define assert(pred, msg) {if (!(pred)) {printf("assert_err: %s\n", msg); exit(1);}}

#define LINESIZE 512

typedef struct Record {
    char  	api[128];
    int 	cnt;
    int		avg;
    int		max;
} Record;

Record records[100];

struct Config {
#define NFILES 100
    char 	logdir[256];
    char	logs[NFILES][64];
    off_t	offsets[NFILES];
    int 	nlogs;
    int		nrecords;
} conf;

int
find_idx(char *fname)
{
    for (int i = 0; i < NFILES; i++) {
        if (strcmp(conf.logs[i], fname) == 0)
            return i;
    }
    return -1;
}

void
init(void)
{
    conf.nlogs = 0;
    conf.nrecords = 0;

	struct stat st;

    FILE *fp = fopen("etc/conf", "r");
    if (fp == NULL)
        err_sys("fopen in init()");
    for (char line[LINESIZE]; fgets(line, LINESIZE, fp) != NULL; ) {
        char fname[64];
        int offset = 0;
        sscanf(line, "%s %d", fname, &offset);

        if (stat(fname, &st) == -1 || S_ISDIR(st.st_mode))
            continue;
        strcpy(conf.logs[conf.nlogs], fname);
        conf.offsets[conf.nlogs++] = offset;
    }
    fclose(fp);

    DIR 			*dp = opendir("./");
    if (dp == NULL)
        err_sys("opendir in init()");

    struct dirent 	*dirp;
    while ((dirp = readdir(dp)) != NULL) {
        if (stat(dirp->d_name, &st) == -1
            || S_ISDIR(st.st_mode)
            || strstr(dirp->d_name, "out.log") == NULL)
            continue;

        int idx = find_idx(dirp->d_name);
        if (idx == -1) {
            strcpy(conf.logs[conf.nlogs], dirp->d_name);
            conf.offsets[conf.nlogs] = 0;
            conf.nlogs++;
        } else if (st.st_size < conf.offsets[idx]) {
            conf.offsets[idx] = 0;
        }
    }
    closedir(dp);

    printf("%d\n", conf.nlogs);
    for (int i = 0; i < conf.nlogs; i++)
        printf("%s, %d\n", conf.logs[i], conf.offsets[i]);

    /* init api statistic */
    fp = fopen("etc/records", "r");
    if (fp == NULL)
        err_sys("fopen in init()");

    for (char line[LINESIZE]; fgets(line, LINESIZE, fp) != NULL; ) {
        char	api[128];
        int		cnt;
        int		avg;
        int		max;

        sscanf(line, "%s %d %d %d", api, &cnt, &avg, &max);
        
        strcpy(records[conf.nrecords].api, api);
        records[conf.nrecords].cnt = cnt;
        records[conf.nrecords].avg = avg;
        records[conf.nrecords].max = max;
        conf.nrecords++;
    }
    fclose(fp);
}

void
fresh(Record *r, int timeout)
{
    r->cnt++;
    r->avg = (int)(((double) r->avg) * (r->cnt - 1)) / r->cnt + ((double) timeout) / r->cnt;
    r->max = MAX(r->max, timeout);
}

void
log_analyses(int token)
{
    FILE *fp = fopen(conf.logs[token], "r");
    if (fp == NULL)
        err_sys("fopen in log_analyses()");
    fseek(fp, conf.offsets[token], 0);

    char line[LINESIZE];
    while (fgets(line, LINESIZE, fp) != NULL) {
        int timeout;

        char *timeout_pos = strrchr(line, ' ');
        if (timeout_pos == NULL || strstr(timeout_pos, "ms") == NULL)
            continue;
        /*
        if (strstr(timeout_pos, "ms") == NULL) {
            printf("===============%s\n", line);
            continue;
        }
        */

        sscanf(timeout_pos, "%d", &timeout);

        for (int i = 0; i < conf.nrecords; i++) {
            if (strstr(line, records[i].api) != NULL) {
                fresh(records + i, timeout);
                break;
            }
        }
    }

    conf.offsets[token] = ftell(fp);
    fclose(fp);
}

void
end_analyses()
{
    FILE *fp = fopen("etc/conf", "w+");
    if (fp == NULL)
        err_sys("fopen in end_analyses");

    for (int i = 0; i < conf.nlogs; i++) {
        fprintf(fp, "%s %ld\n", conf.logs[i], conf.offsets[i]);
    }
    fclose(fp);

    fp = fopen("etc/records", "w+");
    if (fp == NULL)
        err_sys("fopen in end_analyses");
    for (int i = 0; i < conf.nrecords; i++) {
        fprintf(fp, "%s %d %d %d\n", records[i].api, records[i].cnt, records[i].avg, records[i].max);
    }
    fclose(fp);
}

int
main(void)
{
    init();
    for (int i = 0; i < conf.nlogs; i++) {
        log_analyses(i);
    }

    end_analyses();
    printf("%s, %d %d %d\n", records[0].api, records[0].cnt, records[0].avg, records[0].max);
    
    return 0;
}
