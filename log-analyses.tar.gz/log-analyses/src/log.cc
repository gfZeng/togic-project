#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <map>

#include <sys/types.h>

#define err_sys(msg) {printf(msg); exit(1);}

#define assert(pred, msg) {if (!(pred)) {printf("assert_err: %s\n", msg); exit(1);}}

using namespace std;

struct Config {
    string 	logdir;
    off_t 	offset;
} conf;

class Record {
public:
    string 	api;
    int 	cnt;
    int		avg;
    int		max;

    Record(string api);
    void fresh(int timeout);
};

map<string, Record*> records;
typedef map<string, Record*>::iterator iRecord;

Record::Record(string api)
{
    this->api = api;
    this->cnt = 0;
    this->avg = 0;
    this->max = 0;
}

void
Record::fresh(int timeout)
{
    printf("catch it");
    this->cnt++;
    this->avg = (int)(((double) (cnt - 1)) / cnt * this->avg + timeout * 1.0 / cnt);
    if (timeout > this->max)
        this->max = timeout;
}



void
init(void)
{
    conf.logdir = "pm2.log";
    conf.offset = 0;
}


void
log_analyses(void)
{
#define LINESIZE 512
    FILE *fp = fopen(conf.logdir.c_str(), "r");
    assert(fp != NULL, "cant find file");
    fseek(fp, conf.offset, 0);

    char *line = (char *) malloc(sizeof(char) * LINESIZE);
    assert(line != NULL, "malloc in log_analyses");

    while((line = fgets(line, LINESIZE, fp)) != NULL) {
        printf(line);
        printf(strrchr(line, ' '));

        int timeout;
        sscanf(strrchr(line, ' '), "%d", &timeout);

        printf("%d\n", timeout);

        for (iRecord r = records.begin(); r != records.end(); r++) {
            printf(r->first.c_str());
            printf("\n");
            if (strstr(line, r->first.c_str()) != NULL) {
            printf(r->first.c_str());
            printf("\n");
            printf("%p\n", records[r->first]);
                records[r->first]->fresh(timeout);
                break;
            }
        }
    }
    

    free(line);
    fclose(fp);
}

int
main(void)
{
    char s[300];
    int c = 0;
    int d = 0;
    int f = 0;
    sscanf("/getserver 3 4 \n", "%s %d %d %d", s, &c, &d, &f);
    printf(s);
    putchar('\n');
    printf("%d\n", f);
    printf("%d\n", d);
    //return -1;
    printf("%p\n", records[string("/getServerConfig")]);
    init();
    records.insert(pair<string, Record*>(string("/getServerConfig"), new Record("/getServerConfig")));
    printf("==========%p\n", records["/getServerConfig"]);
    printf("--------------\n");

    log_analyses();

    printf("%d\n", records["/getServerConfig"]->cnt);
    printf("%d\n", records["/getServerConfig"]->avg);
    printf("%d\n", records["/getServerConfig"]->max);
    return 0;
}
