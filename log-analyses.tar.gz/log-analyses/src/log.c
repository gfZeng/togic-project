#include "apue.h"
#include <sys/types.h>

struct Config {
    char *log;
    off_t offset;
} conf;

typedef struct Record {
    char 	*api;
    int 	count;
    int 	average;
    int 	max;
} Record;

typedef struct Records {
    char 	*api;
    Record 	*r;
} Records;

void
init(void)
{
    conf.log = "pm2.log";
    conf.offset = 0;
}

void
log_anayses(FILE *fp, off_t start_pos)
{

}

int
main(void)
{
    init();

    FILE *fp = fopen(conf.log, "r");
    if (fp == NULL)
        err_sys("fopen(): %s", conf.log);

    log_anayses(fp, conf.offset);
    fp.close();
}
