must done before
===================

### add the api-name that you want to statistic to /etc/togic/api_statistics.conf

such as:
`
/getServerConfig
/isInit
`
