#include "apue.h"
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <stdbool.h>

#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define assert(pred, msg) {if (!(pred)) {printf("assert_err: %s\n", msg); exit(1);}}

#define LINESIZE 512
#define PATH_LEN_SIZE 256


#define SEARCH_MAX "time_max"
#define SEARCH_CNT "count"
#define SEARCH_AVG "time_average"

#define LOG_FILENAME_SUFFIX ".log"

#define OFFSET_LOG "/tmp/offset.log"
#define STATISTICS_LOG "/tmp/api_statistics.log"
#ifndef API_CONF
#define API_CONF "/etc/togic/api_statistics.conf"
#endif

typedef struct Record {
    char  	api[128];
    int64_t total;
    int 	cnt;
    int		avg;
    int		max;
} Record;

Record records[100];

struct Config {
#define NFILES 100
    char 	logdir[PATH_LEN_SIZE];
    char	logs[NFILES][PATH_LEN_SIZE];
    off_t	offsets[NFILES];
    int 	nlogs;
    int		nrecords;
} conf;

int
find_idx(char *fname)
{
    for (int i = 0; i < NFILES; i++) {
        if (strcmp(conf.logs[i], fname) == 0)
            return i;
    }
    return -1;
}

char *
log_path(char *fname)
{
    int logdir_len = strlen(conf.logdir);
    int fname_len = strlen(fname);
    char *path = (char *) malloc(sizeof(char) * (logdir_len + fname_len + 1));
    memcpy(path, conf.logdir, logdir_len);
    memcpy(path + logdir_len, fname, fname_len);
    *(path + logdir_len + fname_len) = '\0';

    return path;
}

bool
ends_with(const char *str, const char *suffix)
{
    int suffix_len = strlen(suffix);
    if (strncmp(str + strlen(str) - suffix_len, suffix, suffix_len) == 0)
        return true;
    return false;
}

bool
is_logfile(const char *fname)
{
    return strstr(fname, "out") != NULL && ends_with(fname, LOG_FILENAME_SUFFIX);
}

void
init(void)
{
    conf.nlogs = 0;
    conf.nrecords = 0;

	struct stat st;

    FILE *fp = fopen(OFFSET_LOG, "r");
    if (fp != NULL) {
        for (char line[LINESIZE]; fgets(line, LINESIZE, fp) != NULL; ) {
            char fname[64];
            off_t offset = 0;
            sscanf(line, "%s %ld", fname, &offset);

            if (stat(fname, &st) == -1 || S_ISDIR(st.st_mode))
                continue;
            strcpy(conf.logs[conf.nlogs], fname);
            conf.offsets[conf.nlogs++] = offset;
        }
        fclose(fp);
    }

    DIR 			*dp = opendir(conf.logdir);
    if (dp == NULL)
        err_sys("opendir in init()");

    struct dirent 	*dirp;
    while ((dirp = readdir(dp)) != NULL) {
        if (stat(log_path(dirp->d_name), &st) == -1
            || S_ISDIR(st.st_mode)
            || !is_logfile(dirp->d_name)
            //|| !ends_with(dirp->d_name, LOG_FILENAME_SUFFIX)
            //|| strstr(log_path(dirp->d_name), LOG_FILENAME_SUFFIX) == NULL
            )
            continue;

        int idx = find_idx(log_path(dirp->d_name));
        if (idx == -1) {
            strcpy(conf.logs[conf.nlogs], log_path(dirp->d_name));
            conf.offsets[conf.nlogs] = 0;
            conf.nlogs++;
        } else if (st.st_size < conf.offsets[idx]) {
            conf.offsets[idx] = 0;
        }
    }
    closedir(dp);

    for (int i = 0; i < conf.nlogs; i++)
        printf("read %s from %ld\n", conf.logs[i], conf.offsets[i]);

    /* init api statistic */
    fp = fopen(API_CONF, "r");
    if (fp == NULL)
        err_sys("no such file: %s\n"
                "fopen in init()",
                API_CONF);

    for (char line[LINESIZE]; fgets(line, LINESIZE, fp) != NULL; ) {
        if (*line == '\0' || *line == ' ' || *line == '\n')
            continue;

        char	api[128];
        int		cnt;
        int     total;
        int		avg;
        int		max;

        //sscanf(line, "%s %d %d %d", api, &cnt, &avg, &max);
        sscanf(line, "%s", api);
        total = cnt = avg = max = 0;
        //printf("===== %s %d %d %d\n", api, cnt, avg, max);
        
        strcpy(records[conf.nrecords].api, api);
        records[conf.nrecords].total = total;
        records[conf.nrecords].cnt = cnt;
        records[conf.nrecords].avg = avg;
        records[conf.nrecords].max = max;
        conf.nrecords++;
    }
    fclose(fp);
}

void
fresh(Record *r, int timeout)
{
    r->cnt++;
    r->total += timeout;
    //r->avg = (int)(((double) r->avg) * (r->cnt - 1)) / r->cnt + ((double) timeout) / r->cnt;
    r->max = MAX(r->max, timeout);
}

void
log_analyses(int token)
{
    FILE *fp = fopen(conf.logs[token], "r");
    if (fp == NULL)
        err_sys("fopen in log_analyses()");
    fseek(fp, conf.offsets[token], 0);

    char line[LINESIZE];
    while (fgets(line, LINESIZE, fp) != NULL) {
        int timeout;

        char *timeout_pos = strrchr(line, ' ');
        if (timeout_pos == NULL || strstr(timeout_pos, "ms") == NULL)
            continue;
        sscanf(timeout_pos, "%d", &timeout);

        for (int i = 0; i < conf.nrecords; i++) {
            if (strstr(line, records[i].api) != NULL) {
                fresh(records + i, timeout);
                break;
            }
        }
    }

    conf.offsets[token] = ftell(fp);
    fclose(fp);
}

void
end_analyses(void)
{
    FILE *fp = fopen(OFFSET_LOG, "w+");
    if (fp == NULL)
        err_sys("fopen in end_analyses");

    for (int i = 0; i < conf.nlogs; i++) {
        fprintf(fp, "%s %ld\n", conf.logs[i], conf.offsets[i]);
    }
    fclose(fp);

    fp = fopen(STATISTICS_LOG, "w+");
    if (fp == NULL)
        err_sys("fopen in end_analyses");
    for (int i = 0; i < conf.nrecords; i++) {
        fprintf(fp, "%s %d %ld %d\n", records[i].api, records[i].cnt, records[i].total, records[i].max);
    }
    fclose(fp);

    printf("\n\n");
    for (int i = 0; i < conf.nlogs; i++)
        printf("read %s to %ld\n", conf.logs[i], conf.offsets[i]);
}

void
set_logdir(char *path)
{
    if (path == NULL)
        err_quit("please specify a director");

    strcpy(conf.logdir, path);
    int logdir_len = strlen(conf.logdir);
    if (conf.logdir[logdir_len - 1] != '/') {
        conf.logdir[logdir_len] = '/';
        conf.logdir[logdir_len + 1] = '\0';
    }
}

void
search(char *api_name, char *scale)
{

    if (scale == NULL)
        err_quit("must give me a scale");

    int ret = -1;

    FILE *fp = fopen(STATISTICS_LOG, "r");
    if (fp == NULL)
        err_quit("not any results of statistics");

    for (char line[LINESIZE]; fgets(line, LINESIZE, fp) != NULL; ) {
        if (strncmp(line, api_name, strlen(api_name)) != 0)
            continue;

        char	api[128];
        int		cnt;
        int		total;
        int		max;
        sscanf(line, "%s %d %d %d", api, &cnt, &total, &max);

        if (strcmp(scale, SEARCH_CNT) == 0)
            ret = cnt;
        else if (strcmp(scale, SEARCH_AVG) == 0)
            ret = (cnt == 0 ? 0 : total / cnt);
        else if (strcmp(scale, SEARCH_MAX) == 0)
            ret = max;
        else
            err_quit("invalid scale name: %s", scale);
        break;
    }
    fclose(fp);

    if (ret != -1) {
        printf("%d\n", ret);
        return;
    }
    err_quit("not statistics about this api: %s", api_name);
}

int
main(int argc, char *argv[])
{
    if (argc < 2)
        err_quit("USAGE:\n"
                    "\t%s -a logdir --- analyses the log file that in logdir\n"
                    //"\t%s -s <api-name> --- check statistics of api, default is show all api\n",
                    "\t%s api %s|%s|%s\n",
                argv[0], argv[0], SEARCH_AVG, SEARCH_CNT, SEARCH_MAX);

    if (strcmp(argv[1], "-a") == 0) {
        set_logdir(argv[2]);
    } else {
        search(argv[1], argv[2]);
        return 0;
    }


    init();
    for (int i = 0; i < conf.nlogs; i++) {
        log_analyses(i);
    }

    end_analyses();
    
    return 0;
}
